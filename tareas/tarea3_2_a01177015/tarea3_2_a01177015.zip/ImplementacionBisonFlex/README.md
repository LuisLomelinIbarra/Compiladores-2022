# Tarea 3.2
Me base para esta impelemntación en el tutorial de Johnathan Beard el cual se puede encontrar en:
https://www.jonathanbeard.io/tutorials/FlexBisonC++

Me ayudo a entender mejor como utilizar la herramienta y use el ejemplo como base para construir una impelmentación para esta tarea.
De igual manera investigue un poco más por mi cuenta de las herramientas y adapte lo mejor posible para la tarea. Similarmente para no batallar por las diferentes versiones que estan disponibles en windows y en linux utilize una máquina virtual de linux para hacer la impelmentación con flex y bison.
