# Avance del LéxicoSintaxis
Por el momento se realizo el lexer y parser con los diagramas en la propuesta. En este avance se entrega un programa de python que puede leer y aceptar (o rechazar) un archivo en el lenguaje. Se realizaron dos archivos de prueba validos el cual es un helloworld y un archvio con operaciones y una función de factorial. En las pruebas realizadas regresa aceptado para los dos archivos. Faltan hacer más archivos de prueba para ver si se encuentran errores en el programa o si se debe de hacer un cambio a la gramática (en un caso extremo).

Actualmente el programa debe de:
- Compilar sin errores
- Leer un archivo y decidir si es o no el lenguaje
- Indicar la linea del error si se encontro alguno
